package rbd5188.psu.edu.com.finalproject;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Vector;

@RestController
public class MessageController {
    private UserRepository userRepository;

    @Autowired
    public MessageController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/get_messages")
    public List<Message> getMessages() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user =this.userRepository.findByUserName(username);
        List<Message> temp =user.getMessages();
        user.clearMessages();
        this.userRepository.save(user);
        return temp;

    }

    @PostMapping("/send_message")
    public String sendMessage(@RequestBody Message message) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        message.setSender(username);
        if (message.getMessage().length() > 0) {
            User user=this.userRepository.findByUserName(message.getRecipient());
            user.addMessage(message);
            //User harry = new User("john","password","ADMIN");
            this.userRepository.save(user);
            return "message sent to: " + message.getRecipient();

        } else {

            return "message empty";
        }
    }
}
