package rbd5188.psu.edu.com.finalproject;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Message  {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(nullable = false)
    private String recipient;
    @Column(nullable = false)
    private String message;
    //@Column(nullable = false)
    private String sender;


    public Message(String recipient, String message){
        this.recipient = recipient;
        this.message=message;
        this.sender="";
    }
    public Message(Message message){
        this.id=message.id;
        this.recipient=message.getRecipient();
        this.message=message.getMessage();
        this.sender=message.getSender();
    }
    public Message(){
        this.recipient="";
        this.message="";
        this.sender="";
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

}
