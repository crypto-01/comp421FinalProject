package rbd5188.psu.edu.com.finalproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class DbInit implements CommandLineRunner {
    private UserRepository userRepository;

    public DbInit(UserRepository userRepository){
        this.userRepository =userRepository;

    }

    @Override
    public void run(String... args) throws Exception {
        //create users
        User harry = new User("harry","password","ADMIN");
        User user = new User("potter","password","USER");
        //user.addMessage(new Message("potter","hrllo"));
        List<User> users= Arrays.asList(harry,user);
        //save to database;
        userRepository.saveAll(users);


    }
}
