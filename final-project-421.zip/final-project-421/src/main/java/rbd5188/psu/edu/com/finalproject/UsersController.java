package rbd5188.psu.edu.com.finalproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class UsersController {
    //@Autowired
    private UserRepository userRepository;
    @Autowired
     public UsersController(UserRepository userRepository){
    this.userRepository=userRepository;
    }
    public UsersController(){

    }

    @GetMapping("/users")
    @ResponseBody
    public List<User> getUsers() {
         return userRepository.findAll();
        //return "Testing";
    }
    @GetMapping("/getusername")
    @ResponseBody
    public String getName(){
        String name= SecurityContextHolder.getContext().getAuthentication().getName();
        return name;
    }

   @RequestMapping(value="/login", method = RequestMethod.GET)
    public String getLogin(){
       return "login";
   }
   @PostMapping("/sign_up")
   @ResponseBody
   public String signUp(@RequestBody User user){
        User temp=userRepository.findByUserName(user.getUserName());
        if(user.getUserName().length()<4 || user.getPassword().length()<6){
            return "userName or password too short";
        }
        if(temp==null) {
            userRepository.save(user);
            return "sign_up complete";
        }
        else{

            return "user_name taken";
        }
   }
   @PutMapping("/update_password")
    @ResponseBody
    public String updatePassword(@RequestParam(name="old_password") String oldPassword,@RequestParam(name="new_password") String newPassword){
       String name= SecurityContextHolder.getContext().getAuthentication().getName();
       User user=userRepository.findByUserName(name);
       String password= user.getPassword();
       if(password.equals(oldPassword)){
           user.setPassword(newPassword);
           return "password updated";
       }
       else{
           return "incorrect password";
       }
   }

}
