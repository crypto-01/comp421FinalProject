package rbd5188.psu.edu.com.finalproject;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailServiceConfig implements UserDetailsService {

    private  UserRepository userRepository;
    public UserDetailServiceConfig( UserRepository userRepository){
        this.userRepository=userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        User user = this.userRepository.findByUserName(s);
        if (user == null) {
            throw new UsernameNotFoundException(s);
        }
         UserDetailConfig userDetailConfig = new UserDetailConfig(user);

        return userDetailConfig;
    }
}
