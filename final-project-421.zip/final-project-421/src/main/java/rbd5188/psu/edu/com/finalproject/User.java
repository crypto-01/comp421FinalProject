package rbd5188.psu.edu.com.finalproject;

import javax.persistence.*;
import java.util.*;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(nullable = false)
    private String userName;
    @Column(nullable = false)
    private String password;
    private String roles;
    private String permisions;
    private int active;
    @OneToMany(cascade = CascadeType.ALL)
    private List<Message> messages=new ArrayList<>();
    public User(String userName,String password, String role){
        this.userName=userName;
        this.password=password;
        this.roles=role;
        this.active=1;
        this.permisions="";
    }
    public User(){
        this.userName="";
        this.password="";
        this.roles="USER";
        this.active=0;
        this.permisions="";

    }
    public User(String userName,String password){
        this.userName=userName;
        this.password=password;
        this.roles="USER";
        this.active=1;
        this.permisions="";
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String role) {
        this.roles = role;
    }

    public String getPermisions() {
        return permisions;
    }

    public void setPermisions(String permisions) {
        this.permisions = permisions;
    }
    public List<String> getRoleList(){
        if(roles.length()>0){
            return Arrays.asList(roles.split(","));
        }
        return new ArrayList<>();
    }
    public List<String> getPermissionList(){
        if(permisions.length()>0){
            return Arrays.asList(permisions.split(","));
        }
      return new ArrayList<>();
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
    public void addMessage(Message message){
        this.messages.add(message);
    }

    public List<Message> getMessages() {
        return new ArrayList<Message>(messages);
    }
    public void clearMessages(){
        this.messages.clear();
    }
}
